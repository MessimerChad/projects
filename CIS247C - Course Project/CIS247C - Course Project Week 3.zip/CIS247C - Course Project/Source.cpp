/*
Chad Messimer
05/24/2020
CIS247C Course Project
*/

#include <iostream>

#include <string>

#include <fstream>

#include <iomanip> // setw, setprecision

#include "Engine.h"

#include "Car.h"
using namespace std;

/// Entry point for the application

// prototypes

void saveToFile(Car* ptrCar);

int main()
{

	// create two Car objects -- use default and parameterized constructors
	Car firstCar;
	Engine motor(8, 315);Car secondCar("X2345678901234567", "Ford", "Mustang", 2010, 8500.0, 2, false, motor);

	// check the size
	cout << "Size of Car object: " << sizeof(firstCar) << endl;
	cout << "Size of pointer to Car object: " << sizeof(&firstCar) << endl; // MUCH smaller!

	cout << endl; // blank line

	// delete file if it exists
	remove("data.txt");

	// call the method to write your Car to the file
	saveToFile(&firstCar); // notice the & which means "Address of"
	saveToFile(&secondCar);

	//pause
	cout << endl;
	system("pause");

	return 0;
}

void saveToFile(Car* ptrCar)
{
	// open the pipe to the file
	ofstream outToFile("data.txt", ios::app); // app means "Append"

	// if the file is open, write the data to the file
	if (outToFile.is_open())
	{
		// notice that we dereference the Car pointer using an arrow!
		outToFile << ptrCar->getVin() << endl;
		outToFile << ptrCar->getMake() << endl;
		outToFile << ptrCar->getModel() << endl;
		outToFile << ptrCar->getYear() << endl;
		outToFile << ptrCar->getPrice() << endl;
		outToFile << ptrCar->getNumDoors() << endl;
		outToFile << ptrCar->getHatchback() << endl;
		outToFile << ptrCar->getMotor().getNumCylinders() << endl; // This is composition!
		outToFile << ptrCar->getMotor().getHorsePower() << endl; // This is composition

		// close the pipe
		outToFile.close();

		// tell user that the data was written
		cout << ptrCar->getMake() << "" << ptrCar->getModel() << "\nData was written to the file!" << endl;
	}
}