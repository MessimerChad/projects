/*
Chad Messimer
05/24/2020
CIS247C Course Project
*/

#include <iostream>

#include <string>

#include <fstream>

#include <iomanip> // setw, setprecision

#include "Vehicle.h"

#include "SUV.h"

#include "GasCar.h""

#include "ElectricCar.h"

#include "Engine.h"

#include "Car.h"
using namespace std;

/// Entry point for the application

// prototypes

void saveToFile(ElectricCar* ptrElectricCar);
void saveToFile(GasCar* ptrGasCar);
void saveToFile(SUV* ptrSUV);
void saveToFile(Car* ptrCar);
void saveToFile(Vehicle* ptrCar);

int main()
{
	// create your Vehicles using specific classes
	Vehicle veh1("V24456", "Tesla", "Roadster", 2020, 80000.0, Engine(4, 100));
	Car car1("Za45356", "Ford", "Mustang", 2010, 10000.0, 2, false, Engine(8, 315));
	SUV suv1("S45893", "Honda", "Civic", 2018, 24000.0, 8, 47.7f, Engine(6, 250));
	GasCar gas1("E459345", "Chevy", "Corvette", 2010, 20000, 2, false, 18, 19, Engine(0, 271));
	ElectricCar electric1("G124589", "Nissan", "Pathfinder", 2018, 25000.0, 4, false, 75, 240, 136, Engine(0, 327));

	// check the size
	cout << "Size of Car object: " << sizeof(car1) << endl; // VERY LARGE
	cout << "Size of pointer to Car object: " << sizeof(&car1) << endl; // blank line

	cout << endl; // blank line

	// delete file if it exists
	remove("data.txt");

	// call the method to write your Car to the file
	saveToFile(&veh1); // notice the & which means "Address of"
	saveToFile(&car1);
	saveToFile(&suv1);
	saveToFile(&gas1);
	saveToFile(&electric1);

	//pause
	cout << endl;
	system("pause");

	return 0;
}

void saveToFile(ElectricCar* ptrElectricCar)
{
	// open the pipe to the file
	ofstream outToFile("data.txt", ios::app); // app means "Append"

	// if the file is open, write the data to the file
	if (outToFile.is_open())
	{
		// notice that we dereference the Car pointer using an arrow!
		outToFile << ptrElectricCar->getVin() << ',' << ptrElectricCar->getMake() << ','
			<< ptrElectricCar->getModel() << ',' << ptrElectricCar->getYear() << ','
			<< ptrElectricCar->getPrice() << ',' << ptrElectricCar->getNumDoors() << ','
			<< ptrElectricCar->getHatchback() << ','
			<< ptrElectricCar->getBatterySize() << ','
			<< ptrElectricCar->getRange() << ','
			<< ptrElectricCar->getMpgE() << ','
			<< ptrElectricCar->getMotor().getNumCylinders() << ',' // Notice the composition!
			<< ptrElectricCar->getMotor().getHorsePower() << endl;

		// close the pipe
		outToFile.close();

		// tell the user that the data was written 
		cout << ptrElectricCar->getMake() << " " << ptrElectricCar->getModel() << " was written to the file!"
			<< endl;
 	}
}

void saveToFile(GasCar* ptrGasCar)
{
	// open the pipe to the file
	ofstream outToFile("data.txt", ios::app); // app means "Append"

	// if the file is open, write the data to the file
	if (outToFile.is_open())
	{
		// notice that we dereference the Car pointer using an arrow!
		outToFile << ptrGasCar->getVin() << ',' << ptrGasCar->getMake() << ','
			<< ptrGasCar->getModel() << ',' << ptrGasCar->getYear() << ','
			<< ptrGasCar->getPrice() << ',' << ptrGasCar->getNumDoors() << ','
			<< ptrGasCar->getHatchback() << ','
			<< ptrGasCar->getTankSize() << ','
			<< ptrGasCar->getMPG() << ','
			<< ptrGasCar->getMotor().getNumCylinders() << ',' // Notice the composition!
			<< ptrGasCar->getMotor().getHorsePower() << endl;

		// close the pipe
		outToFile.close();

		// tell the user that the data was written 
		cout << ptrGasCar->getMake() << " " << ptrGasCar->getModel() << " was written to the file!"
			<< endl;
	}
}

void saveToFile(SUV* ptrSUV)
{
	// open the pipe to the file
	ofstream outToFile("data.txt", ios::app); // app means "Append"

	// if the file is open, write the data to the file
	if (outToFile.is_open())
	{
		// notice that we dereference the Car pointer using an arrow!
		outToFile << ptrSUV->getVin() << ',' << ptrSUV->getMake() << ','
			<< ptrSUV->getModel() << ',' << ptrSUV->getYear() << ','
			<< ptrSUV->getPrice() << ',' << ptrSUV->getNumSeats() << ','
			<< ptrSUV->getCargoSize() << ','
			<< ptrSUV->getMotor().getNumCylinders() << ',' // Notice the composition!
			<< ptrSUV->getMotor().getHorsePower() << endl;

		// close the pipe
		outToFile.close();

		// tell the user that the data was written 
		cout << ptrSUV->getMake() << " " << ptrSUV->getModel() << " was written to the file!"
			<< endl;
	}
}

void saveToFile(Car* ptrCar)
{
	// open the pipe to the file
	ofstream outToFile("data.txt", ios::app); // app means "Append"

	// if the file is open, write the data to the file
	if (outToFile.is_open())
	{
		// notice that we dereference the Car pointer using an arrow!
		outToFile << ptrCar->getVin() << ',' << ptrCar->getMake() << ','
			<< ptrCar->getModel() << ',' << ptrCar->getYear() << ','
			<< ptrCar->getPrice() << ',' << ptrCar->getNumDoors() << ','
			<< ptrCar->getHatchback() << ','
			<< ptrCar->getMotor().getNumCylinders() << ',' //Notice the composition
			<< ptrCar->getMotor().getHorsePower() << endl;


		// close the pipe
		outToFile.close();

		// tell user that the data was written
		cout << ptrCar->getMake() << "" << ptrCar->getModel() << " was written to the file!" << endl;
	}
}

void saveToFile(Vehicle* ptrVehicle)
{
	// open the pipe to the file
	ofstream outToFile("data.txt", ios::app); // app means "Append"

	// if the file is open, write the data to the file
	if (outToFile.is_open())
	{
		// notice that we dereference the Car pointer using an arrow!
		outToFile << ptrVehicle->getVin() << ',' << ptrVehicle->getMake() << ','
			<< ptrVehicle->getModel() << ',' << ptrVehicle->getYear() << ','
			<< ptrVehicle->getPrice() << ',' 
			<< ptrVehicle->getMotor().getNumCylinders() << ',' //Notice the composition
			<< ptrVehicle->getMotor().getHorsePower() << endl;


		// close the pipe
		outToFile.close();

		// tell user that the data was written
		cout << ptrVehicle->getMake() << "" << ptrVehicle->getModel() << " was written to the file!" << endl;
	}
}